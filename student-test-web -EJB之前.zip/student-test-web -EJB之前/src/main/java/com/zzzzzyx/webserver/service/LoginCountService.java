package com.zzzzzyx.webserver.service;

import com.zzzzzyx.webserver.model.LoginCountBean;

public interface LoginCountService {

	public LoginCountBean getLoginCountBean();
}
