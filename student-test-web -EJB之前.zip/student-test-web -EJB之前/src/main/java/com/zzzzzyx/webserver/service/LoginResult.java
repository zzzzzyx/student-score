package com.zzzzzyx.webserver.service;

public enum LoginResult {

	NotExist,PswIncorrect,Login
}
